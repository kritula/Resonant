using System.Collections.Generic;
using UnityEngine;

namespace OmniumLessons
{
    public class SlowAbility : AbilityBehaviour
    {
        [Header("Visual")]
        [SerializeField] private Transform _visualZone;

        [Header("Visual Settings")]
        [SerializeField] private float _visualBaseSize = 1f;

        private SlowAbilityData _slowAbilityData;
        private readonly Dictionary<Character, float> _slowedEnemies = new Dictionary<Character, float>();

        public override void Initialize(Character owner, AbilityData data)
        {
            base.Initialize(owner, data);

            _slowAbilityData = data as SlowAbilityData;

            if (_slowAbilityData == null)
            {
                Debug.LogError("SlowAbility: data is not SlowAbilityData");
                return;
            }

            transform.localPosition = Vector3.zero;
            transform.localRotation = Quaternion.identity;

            UpdateVisualScale();

            Debug.Log("SlowAbility initialized. Radius = " + _slowAbilityData.Radius);
        }

        public override void OnUpdate()
        {
            if (_owner == null || _slowAbilityData == null)
            {
                return;
            }

            transform.localPosition = Vector3.zero;

            ApplySlowToEnemiesInRadius();
            RemoveSlowFromEnemiesOutsideRadius();
        }

        private void UpdateVisualScale()
        {
            if (_visualZone == null)
            {
                Debug.LogWarning("SlowAbility: _visualZone is null");
                return;
            }

            float diameter = _slowAbilityData.Radius * 2f;
            float scaleValue = diameter / _visualBaseSize;

            _visualZone.localScale = new Vector3(scaleValue, 0.1f, scaleValue);

            Debug.Log("SlowAbility visual updated. Radius = " + _slowAbilityData.Radius +
                      ", Diameter = " + diameter +
                      ", New scale = " + _visualZone.localScale);
        }

        private void ApplySlowToEnemiesInRadius()
        {
            Collider[] colliders = Physics.OverlapSphere(_owner.transform.position, _slowAbilityData.Radius);

            for (int i = 0; i < colliders.Length; i++)
            {
                Character target = colliders[i].GetComponentInParent<Character>();

                if (target == null)
                {
                    continue;
                }

                if (target == _owner)
                {
                    continue;
                }

                if (target.CharacterType == CharacterType.DefaultPlayer)
                {
                    continue;
                }

                if (target.LiveComponent == null || target.LiveComponent.IsAlive == false)
                {
                    continue;
                }

                if (target.MovableComponent == null)
                {
                    continue;
                }

                if (_slowedEnemies.ContainsKey(target))
                {
                    continue;
                }

                float originalSpeed = target.MovableComponent.Speed;
                float slowedSpeed = Mathf.Max(0.1f, originalSpeed * (1f - _slowAbilityData.SlowPercent));

                target.MovableComponent.Speed = slowedSpeed;
                _slowedEnemies.Add(target, originalSpeed);
            }
        }

        private void RemoveSlowFromEnemiesOutsideRadius()
        {
            List<Character> enemiesToRestore = new List<Character>();

            foreach (KeyValuePair<Character, float> pair in _slowedEnemies)
            {
                Character enemy = pair.Key;

                if (enemy == null)
                {
                    enemiesToRestore.Add(enemy);
                    continue;
                }

                if (enemy.MovableComponent == null)
                {
                    enemiesToRestore.Add(enemy);
                    continue;
                }

                if (enemy.LiveComponent == null || enemy.LiveComponent.IsAlive == false)
                {
                    enemy.MovableComponent.Speed = pair.Value;
                    enemiesToRestore.Add(enemy);
                    continue;
                }

                float distance = Vector3.Distance(_owner.transform.position, enemy.transform.position);

                if (distance > _slowAbilityData.Radius)
                {
                    enemy.MovableComponent.Speed = pair.Value;
                    enemiesToRestore.Add(enemy);
                }
            }

            for (int i = 0; i < enemiesToRestore.Count; i++)
            {
                _slowedEnemies.Remove(enemiesToRestore[i]);
            }
        }

        private void OnDestroy()
        {
            RestoreAllSpeeds();
        }

        private void RestoreAllSpeeds()
        {
            foreach (KeyValuePair<Character, float> pair in _slowedEnemies)
            {
                Character enemy = pair.Key;

                if (enemy == null)
                {
                    continue;
                }

                if (enemy.MovableComponent == null)
                {
                    continue;
                }

                enemy.MovableComponent.Speed = pair.Value;
            }

            _slowedEnemies.Clear();
        }
    }
}