using UnityEngine;

namespace OmniumLessons
{
    public class HexCellView : MonoBehaviour
    {
        public HexCoord Coord { get; private set; }

        private IHexTileMechanic[] _tileMechanics;

        private void Awake()
        {
            _tileMechanics =
                GetComponentsInChildren<IHexTileMechanic>(true);
        }

        public void Initialize(
            HexCoord coord,
            Vector3 worldPosition)
        {
            Coord = coord;
            transform.position = worldPosition;

            ResetTileMechanics();
        }

        public void UpdateCell(
            HexCoord coord,
            Vector3 worldPosition)
        {
            Coord = coord;
            transform.position = worldPosition;

            ResetTileMechanics();
        }

        public void SetVisible(bool value)
        {
            gameObject.SetActive(value);
        }

        private void ResetTileMechanics()
        {
            if (_tileMechanics == null)
                return;

            for (int i = 0; i < _tileMechanics.Length; i++)
            {
                _tileMechanics[i].ResetMechanic();
            }
        }
    }
}