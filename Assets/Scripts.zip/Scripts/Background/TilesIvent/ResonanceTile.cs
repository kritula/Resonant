using UnityEngine;

namespace OmniumLessons
{
    public class ResonanceTile : MonoBehaviour, IHexTileMechanic
    {
        [Header("Renderer")]
        [SerializeField] private Renderer _renderer;

        [Header("Data")]
        [SerializeField] private ResonanceTileData _data;

        private PlayerAttackStatsDecoratorController _playerDecoratorController;
        private ResonanceAttackStatsDecorator _decorator;

        private bool _isResonanceTile;
        private bool _isBuffApplied;
        private bool _isOnCooldown;

        private float _activeTimer;
        private float _cooldownTimer;

        private void Reset()
        {
            _renderer = GetComponentInChildren<Renderer>();
        }

        private void Update()
        {
            UpdateActiveTimer();
            UpdateCooldownTimer();
        }

        private void OnTriggerEnter(Collider other)
        {
            if (_data == null)
                return;

            if (!_isResonanceTile)
                return;

            if (_isOnCooldown)
                return;

            if (_isBuffApplied)
                return;

            PlayerCharacter player =
                other.GetComponentInParent<PlayerCharacter>();

            if (player == null)
                return;

            _playerDecoratorController =
                player.GetComponent<PlayerAttackStatsDecoratorController>();

            if (_playerDecoratorController == null)
                return;

            ApplyBuff();
        }

        private void OnTriggerExit(Collider other)
        {
            if (_data == null)
                return;

            if (!_isResonanceTile)
                return;

            PlayerCharacter player =
                other.GetComponentInParent<PlayerCharacter>();

            if (player == null)
                return;

            RemoveBuff();

            _activeTimer = 0f;

            if (!_isOnCooldown)
                ApplyMaterial(_data.ReadyMaterial);
        }

        private void ApplyBuff()
        {
            _decorator = new ResonanceAttackStatsDecorator(
                _data.DamageMultiplier,
                _data.AttackSpeedMultiplier);

            _playerDecoratorController.AddDecorator(_decorator);

            _isBuffApplied = true;
            _activeTimer = _data.MaxActiveTime;

            ApplyMaterial(_data.ActiveMaterial);

            Debug.Log("Resonance buff applied.");
        }

        private void RemoveBuff()
        {
            if (!_isBuffApplied)
                return;

            if (_playerDecoratorController != null &&
                _decorator != null)
            {
                _playerDecoratorController.RemoveDecorator(_decorator);
            }

            _decorator = null;
            _playerDecoratorController = null;

            _isBuffApplied = false;

            Debug.Log("Resonance buff removed.");
        }

        private void UpdateActiveTimer()
        {
            if (!_isBuffApplied)
                return;

            if (_isOnCooldown)
                return;

            _activeTimer -= Time.deltaTime;

            if (_activeTimer > 0f)
                return;

            RemoveBuff();

            StartCooldown();
        }

        private void StartCooldown()
        {
            _isOnCooldown = true;
            _cooldownTimer = _data.CooldownTime;

            ApplyMaterial(_data.CooldownMaterial);

            Debug.Log("Resonance tile cooldown started.");
        }

        private void UpdateCooldownTimer()
        {
            if (!_isOnCooldown)
                return;

            _cooldownTimer -= Time.deltaTime;

            if (_cooldownTimer > 0f)
                return;

            _isOnCooldown = false;

            if (_isResonanceTile)
                ApplyMaterial(_data.ReadyMaterial);
            else
                ApplyMaterial(_data.DefaultMaterial);

            Debug.Log("Resonance tile cooldown finished.");
        }

        public void ResetMechanic()
        {
            RemoveBuff();

            _isBuffApplied = false;
            _isOnCooldown = false;

            _activeTimer = 0f;
            _cooldownTimer = 0f;

            if (_data == null)
                return;

            _isResonanceTile =
                Random.value <= _data.SpawnChance;

            if (_isResonanceTile)
                ApplyMaterial(_data.ReadyMaterial);
            else
                ApplyMaterial(_data.DefaultMaterial);
        }

        private void ApplyMaterial(Material material)
        {
            if (_renderer == null)
                return;

            if (material == null)
                return;

            _renderer.material = material;
        }
    }
}