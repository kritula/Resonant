using UnityEngine;

namespace OmniumLessons
{
    [CreateAssetMenu(
        fileName = "ResonanceTileData",
        menuName = "OmniumLessons/Hex Tiles/Resonance Tile Data")]
    public class ResonanceTileData : ScriptableObject
    {
        [Header("Materials")]
        public Material DefaultMaterial;
        public Material ReadyMaterial;
        public Material ActiveMaterial;
        public Material CooldownMaterial;

        [Header("Spawn")]
        [Range(0f, 1f)]
        public float SpawnChance = 0.08f;

        [Header("Buff")]
        public float DamageMultiplier = 1.2f;
        public float AttackSpeedMultiplier = 1.15f;

        [Header("Cooldown")]
        public float MaxActiveTime = 5f;
        public float CooldownTime = 8f;
    }
}