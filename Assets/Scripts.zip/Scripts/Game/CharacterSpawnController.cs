﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

namespace OmniumLessons
{
    [Serializable]
    public class EnemySpawnSettings
    {
        public CharacterType CharacterType;
        public float SpawnStartTime;
    }

    public class CharacterSpawnController
    {
        private CharacterFactory CharacterFactory => GameManager.Instance.CharacterFactory;
        private GameData GameData => GameManager.Instance.GameData;

        private float _spawnTimerEnemy;

        private int _baseMaxEnemies = 2;
        private int _enemiesAddedPerStep = 1;
        private float _enemyGrowthIntervalSeconds = 10f;

        private bool _isActiveSpawn;

        private readonly List<EnemySpawnSettings> _enemySpawnSettings = new List<EnemySpawnSettings>
        {
            new EnemySpawnSettings { CharacterType = CharacterType.DefaultEnemy, SpawnStartTime = 0f },
            new EnemySpawnSettings { CharacterType = CharacterType.FastEnemy, SpawnStartTime = 15f },
            new EnemySpawnSettings { CharacterType = CharacterType.TankEnemy, SpawnStartTime = 30f }
        };

        public void StartSpawn()
        {
            _isActiveSpawn = true;
            _spawnTimerEnemy = 0f;
        }

        public void StopSpawn()
        {
            _isActiveSpawn = false;
        }

        public void OnUpdate(float deltaTime)
        {
            if (!_isActiveSpawn)
                return;

            _spawnTimerEnemy += deltaTime;

            float gameTime = GameManager.Instance.GameTime;
            int growthSteps = (int)(gameTime / _enemyGrowthIntervalSeconds);
            int maxEnemiesNow = _baseMaxEnemies + growthSteps * _enemiesAddedPerStep;

            int currentEnemies = CountActiveEnemies();
            if (currentEnemies >= maxEnemiesNow)
                return;

            if (_spawnTimerEnemy >= GameData.TimeBetweenEnemySpawn)
            {
                SpawnEnemy();
                _spawnTimerEnemy = 0f;
            }
        }

        private int CountActiveEnemies()
        {
            int count = 0;
            List<Character> activeCharacters = CharacterFactory.ActiveCharacters;

            for (int i = 0; i < activeCharacters.Count; i++)
            {
                if (activeCharacters[i].CharacterType != CharacterType.DefaultPlayer &&
                    activeCharacters[i].LiveComponent.IsAlive)
                {
                    count++;
                }
            }

            return count;
        }

        private void SpawnEnemy()
        {
            if (CharacterFactory.Player == null)
                return;

            CharacterType enemyType = GetEnemyTypeForSpawn();
            Character enemy = CharacterFactory.CreateCharacter(enemyType);

            Vector3 spawnPoint = GetSpawnPointOutsideScreen();
            enemy.transform.position = spawnPoint;

            GameManager.Instance.RegisterCharacter(enemy);
            enemy.gameObject.SetActive(true);

            Vector3 viewport = Camera.main != null
                ? Camera.main.WorldToViewportPoint(enemy.transform.position)
                : Vector3.zero;

            Debug.Log($"[SPAWN] Type: {enemyType}, player: {CharacterFactory.Player.transform.position}, camera: {(Camera.main != null ? Camera.main.transform.position.ToString() : "no camera")}, point: {enemy.transform.position}, viewport: {viewport}");
        }

        private CharacterType GetEnemyTypeForSpawn()
        {
            float gameTime = GameManager.Instance.GameTime;
            List<CharacterType> availableEnemies = new List<CharacterType>();

            for (int i = 0; i < _enemySpawnSettings.Count; i++)
            {
                if (gameTime >= _enemySpawnSettings[i].SpawnStartTime)
                {
                    availableEnemies.Add(_enemySpawnSettings[i].CharacterType);
                }
            }

            int randomIndex = Random.Range(0, availableEnemies.Count);
            return availableEnemies[randomIndex];
        }

        private Vector3 GetSpawnPointOutsideScreen()
        {
            Camera mainCamera = Camera.main;

            if (mainCamera == null || CharacterFactory.Player == null)
                return Vector3.zero;

            if (!mainCamera.orthographic)
            {
                Debug.LogWarning("CharacterSpawnController: MainCamera must be Orthographic for this spawn logic.");
            }

            Transform playerTransform = CharacterFactory.Player.transform;

            Vector3 cameraCenter = mainCamera.transform.position;
            float groundY = playerTransform.position.y;

            float halfHeight = mainCamera.orthographicSize;
            float halfWidth = halfHeight * mainCamera.aspect;

            float minX = cameraCenter.x - halfWidth;
            float maxX = cameraCenter.x + halfWidth;
            float minZ = cameraCenter.z - halfHeight;
            float maxZ = cameraCenter.z + halfHeight;

            // Ближний отступ — чтобы точно не касаться края экрана
            float outsidePaddingNear = Mathf.Max(GameData.MaxEnemySpawnOffset, 5f);

            // Дальний отступ — ширина полосы спавна
            float outsidePaddingFar = outsidePaddingNear + 6f;

            // Чтобы враги могли спавниться и чуть "за углами", а не только напротив экрана
            float cornerPadding = 4f;

            int side = Random.Range(0, 4);

            switch (side)
            {
                case 0: // Left band
                    return new Vector3(
                        Random.Range(minX - outsidePaddingFar, minX - outsidePaddingNear),
                        groundY,
                        Random.Range(minZ - cornerPadding, maxZ + cornerPadding));

                case 1: // Right band
                    return new Vector3(
                        Random.Range(maxX + outsidePaddingNear, maxX + outsidePaddingFar),
                        groundY,
                        Random.Range(minZ - cornerPadding, maxZ + cornerPadding));

                case 2: // Bottom band
                    return new Vector3(
                        Random.Range(minX - cornerPadding, maxX + cornerPadding),
                        groundY,
                        Random.Range(minZ - outsidePaddingFar, minZ - outsidePaddingNear));

                default: // Top band
                    return new Vector3(
                        Random.Range(minX - cornerPadding, maxX + cornerPadding),
                        groundY,
                        Random.Range(maxZ + outsidePaddingNear, maxZ + outsidePaddingFar));
            }
        }
    }
}